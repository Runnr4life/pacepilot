# PacePilot

PacePilot is a free-first running workspace starter with a responsive Next.js website and an Expo mobile-app starter. The web experience includes an interactive overview, starter-week builder for general fitness/5K/10K/half-marathon/marathon goals, workout library, recovery guidance, analytics placeholder, race center, integration previews, and preferences.

## Run the website locally

Requirements: Node.js 20+ and npm 10+.

```bash
cd apps/web
npm install
npm run dev
```

Open http://localhost:3000.

To make a production build:

```bash
npm run build
npm start
```

## Publish the website with Vercel

1. Push this repository to GitHub.
2. Sign in at https://vercel.com/ and choose **Add New → Project**.
3. Import the `pacepilot` GitHub repository.
4. Set **Root Directory** to `apps/web`.
5. Keep the Framework Preset as **Next.js**. Use `npm install` for install and `npm run build` for build.
6. Deploy. Vercel will provide a public `*.vercel.app` address. A custom domain can be connected later.

## Current scope and important limitations

This is an interactive frontend prototype. Preferences and workout checkmarks are held in browser memory and are not saved to an account or database. Authentication, hosted data persistence, actual activity recording, live Garmin/Strava/COROS OAuth and syncing, and production-grade adaptive coaching are not implemented. Integration controls are clearly marked as previews rather than claiming to connect accounts.

Training examples are intentionally conservative and are not medical advice or a substitute for an individualized plan from a qualified coach. Younger runners should involve a parent/guardian and a qualified coach in structured race training, prioritize recovery, and stop if they feel pain or unwell.

## Project structure

- `apps/web` — Next.js website
- `apps/mobile` — Expo mobile starter
- `packages/core` — shared TypeScript training types/helpers
- `supabase/migrations` — initial database schema for a future backend
- `docs` — integration planning notes
