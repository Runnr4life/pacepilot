import type { Metadata } from "next";
import "./styles.css";

export const metadata: Metadata = {
  title: "PacePilot — Your pace. Your progress.",
  description: "A free-first running workspace for training plans, workouts, recovery, and running goals.",
  applicationName: "PacePilot",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
