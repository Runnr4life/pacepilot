# Integration plan and constraints

PacePilot will use a provider adapter pattern so provider-specific authorization and payloads do not leak into the training domain.

## Strava
- Use Strava's official OAuth 2.0 authorization flow and documented API.
- Request the minimum read scopes first; request write permissions only if workout publishing is explicitly added.
- Verify webhook subscription requirements, rate limits, attribution and display requirements before release.
- Keep client secret and refresh tokens server-side; encrypt stored tokens and support disconnect/revocation.

## Garmin Connect
- Garmin Health API / Garmin Connect Developer Program access is partner-controlled and may require an application review or commercial agreement.
- Do not promise unrestricted consumer-account sync until Garmin approves the intended use case.
- Build an adapter interface and manual FIT/TCX/GPX import fallback while approval is pending.

## COROS
- Confirm current COROS developer/API access and partner requirements with COROS before implementation.
- Keep the adapter behind a feature flag until credentials, scopes and data-use permissions are confirmed.
- Provide manual file import as a fallback.

## Security requirements
- OAuth callback state must be cryptographically random, single-use and short-lived.
- Never put provider secrets or refresh tokens in browser/mobile bundles.
- Validate webhook signatures, deduplicate event IDs, rate-limit callbacks and log sync failures without storing unnecessary raw data.
- Offer disconnect and deletion controls; delete or revoke provider tokens when a connection is removed.

## Adapter contract (planned)
Each adapter should implement `beginAuthorization`, `completeAuthorization`, `refreshCredentials`, `fetchActivities`, and `disconnect`. A sync worker should normalize provider records into `Activity` and upsert by `(athlete_id, provider, provider_activity_id)`.
