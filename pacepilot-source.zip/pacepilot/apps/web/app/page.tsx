"use client";

import { useMemo, useState } from "react";

type Goal = "General fitness" | "5K" | "10K" | "Half-marathon" | "Marathon";
type Tab = "Overview" | "Training plan" | "Workouts" | "Recovery" | "Analytics" | "Race center" | "Integrations" | "Settings";

const nav: { label: Tab; icon: string }[] = [
  { label: "Overview", icon: "▦" }, { label: "Training plan", icon: "◷" },
  { label: "Workouts", icon: "⌁" }, { label: "Recovery", icon: "♡" },
  { label: "Analytics", icon: "↗" }, { label: "Race center", icon: "◎" },
  { label: "Integrations", icon: "⌚" }, { label: "Settings", icon: "⚙" },
];

const initialWeek = [
  ["MON", "Rest & reset", "Recovery", "Rest"], ["TUE", "Easy run", "Easy", "20–30 min"],
  ["WED", "Mobility or playful movement", "Support", "15–20 min"], ["THU", "Easy run", "Easy", "20–30 min"],
  ["FRI", "Rest day", "Recovery", "Rest"], ["SAT", "Comfortable longer run or walk", "Long", "25–40 min"],
  ["SUN", "Rest or gentle walk", "Recovery", "Optional"],
];

function makeWeek(goal: Goal, days: number, level: string) {
  const sessions = Math.max(2, Math.min(4, days));
  const base = level === "New to running" ? 20 : level === "Some running" ? 25 : 30;
  const names = goal === "General fitness" ? ["Easy run", "Easy run", "Comfortable longer run"] : ["Easy run", "Easy run", "Comfortable longer run"];
  return initialWeek.map((day, i) => {
    const runDays = sessions === 2 ? [1, 5] : sessions === 3 ? [1, 3, 5] : [1, 2, 4, 5];
    if (runDays.includes(i)) {
      const index = runDays.indexOf(i);
      const mins = index === runDays.length - 1 ? base + 10 : base;
      return [day[0], names[Math.min(index, names.length - 1)], index === runDays.length - 1 ? "Long" : "Easy", `${mins} min`];
    }
    if (i === 2 && sessions < 4) return [day[0], "Mobility or light strength", "Support", "15–20 min"];
    return [day[0], "Rest and recovery", "Recovery", "Rest"];
  });
}

export default function Home() {
  const [active, setActive] = useState<Tab>("Overview");
  const [goal, setGoal] = useState<Goal>("5K");
  const [level, setLevel] = useState("New to running");
  const [days, setDays] = useState(3);
  const [planReady, setPlanReady] = useState(false);
  const [checked, setChecked] = useState<string[]>([]);
  const [connected, setConnected] = useState<string[]>([]);
  const [name, setName] = useState("Runner");
  const [unit, setUnit] = useState("km");

  const week = useMemo(() => makeWeek(goal, days, level), [goal, days, level]);
  const runs = week.filter((d) => d[2] === "Easy" || d[2] === "Long").length;
  const completeWorkout = (day: string) => setChecked((prev) => prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]);
  const connect = (provider: string) => setConnected((prev) => prev.includes(provider) ? prev.filter((p) => p !== provider) : [...prev, provider]);

  const pageTitle = active === "Overview" ? "Your running workspace" : active;
  return <main className="app-shell">
    <aside className="sidebar">
      <button className="brand" onClick={() => setActive("Overview")} aria-label="PacePilot home"><span className="brand-mark">P</span><span>PacePilot</span></button>
      <div className="nav-label">WORKSPACE</div>
      <nav>{nav.slice(0, 6).map((item) => <button key={item.label} className={`nav-item ${active === item.label ? "active" : ""}`} onClick={() => setActive(item.label)}><span className="nav-icon">{item.icon}</span>{item.label}</button>)}</nav>
      <div className="nav-label account-label">ACCOUNT</div>
      <nav>{nav.slice(6).map((item) => <button key={item.label} className={`nav-item ${active === item.label ? "active" : ""}`} onClick={() => setActive(item.label)}><span className="nav-icon">{item.icon}</span>{item.label}</button>)}</nav>
      <div className="sidebar-bottom"><div className="avatar">{name.slice(0, 1).toUpperCase()}</div><div><b>{name || "Runner"}</b><small>Personal workspace</small></div><span className="online-dot" /></div>
    </aside>

    <section className="main-area">
      <header className="topbar"><div className="breadcrumb">PACEPILOT <span>/</span> {active.toUpperCase()}</div><div className="top-right"><span className="status-dot"/> <span>Personal workspace</span><button className="profile-chip" onClick={() => setActive("Settings")}>{name.slice(0, 1).toUpperCase()}</button></div></header>
      <div className="page-wrap">
        <div className="hero-row"><div><div className="eyebrow">YOUR PACE. YOUR PROGRESS.</div><h1>{active === "Overview" ? <>Build your pace.<br/><em>Find your rhythm.</em></> : pageTitle}</h1><p className="hero-copy">A thoughtful training space that adapts to your goals, your schedule, and your life.</p></div><div className="hero-stamp"><span>✳</span><div><small>YOUR CURRENT GOAL</small><b>{goal}</b></div></div></div>

        {active === "Overview" && <>
          <div className="metric-grid">
            <article className="metric-card"><div className="metric-label">THIS WEEK <span>↗</span></div><div className="metric-value">{checked.length}<small> / {runs}</small></div><div className="metric-caption">Sessions marked complete</div><div className="meter"><i style={{ width: `${runs ? Math.min(100, checked.length / runs * 100) : 0}%` }}/></div></article>
            <article className="metric-card"><div className="metric-label">TRAINING GOAL <span>◎</span></div><div className="metric-value text-value">{goal}</div><div className="metric-caption">Your selected focus</div><div className="metric-bottom">Change it in Training plan</div></article>
            <article className="metric-card"><div className="metric-label">WEEKLY RHYTHM <span>◷</span></div><div className="metric-value">{days}<small> days</small></div><div className="metric-caption">Your chosen training availability</div><div className="metric-bottom">Rest days are part of training</div></article>
            <article className="metric-card coach-card"><div className="metric-label">PACEPILOT NOTE <span>✳</span></div><b>Consistency over intensity.</b><p>Comfortable sessions and enough recovery help make running sustainable.</p></article>
          </div>
          <div className="section-heading"><div><div className="eyebrow">YOUR SCHEDULE</div><h2>This week</h2></div><button className="subtle-button" onClick={() => setActive("Training plan")}>Edit plan <span>↗</span></button></div>
          <div className="schedule-card">{week.map(([day, title, type, duration]) => <div className="schedule-row" key={day}><span className="day-tag">{day}</span><span className={`workout-dot ${type.toLowerCase()}`}/><div className="session-title"><b>{title}</b><small>{type}</small></div><span className="session-duration">{duration}</span><button className={`check-session ${checked.includes(day) ? "done" : ""}`} onClick={() => completeWorkout(day)} aria-label={`${checked.includes(day) ? "Unmark" : "Mark"} ${day} complete`}>{checked.includes(day) ? "✓" : "○"}</button></div>)}</div>
          <div className="section-heading modules-heading"><div><div className="eyebrow">YOUR TOOLKIT</div><h2>Explore PacePilot</h2></div><span className="muted-copy">Everything in one place</span></div>
          <div className="module-grid">{[{icon:"◷",title:"Training plan",desc:"Choose a goal and shape your week.",tab:"Training plan" as Tab},{icon:"⌁",title:"Workout library",desc:"Understand the purpose of each session.",tab:"Workouts" as Tab},{icon:"♡",title:"Recovery",desc:"Make room for rest and reflection.",tab:"Recovery" as Tab},{icon:"↗",title:"Analytics",desc:"See consistency and progress over time.",tab:"Analytics" as Tab},{icon:"◎",title:"Race center",desc:"Keep your event and milestones in view.",tab:"Race center" as Tab},{icon:"⌚",title:"Integrations",desc:"Explore supported activity platforms.",tab:"Integrations" as Tab}].map((m) => <button className="module-card" key={m.title} onClick={() => setActive(m.tab)}><span className="module-icon">{m.icon}</span><b>{m.title}</b><p>{m.desc}</p><span className="module-link">Explore <i>↗</i></span></button>)}</div>
        </>}

        {active === "Training plan" && <div className="content-grid"><section className="panel plan-builder"><div className="panel-kicker">PLAN BUILDER</div><h2>Shape a plan around you.</h2><p className="panel-intro">Start with a goal and a realistic weekly rhythm. You can adjust these choices whenever life changes.</p><label className="field-label" htmlFor="goal">What's your goal?</label><select id="goal" value={goal} onChange={(e) => { setGoal(e.target.value as Goal); setPlanReady(false); }}><option>General fitness</option><option>5K</option><option>10K</option><option>Half-marathon</option><option>Marathon</option></select><label className="field-label" htmlFor="level">Your running experience</label><select id="level" value={level} onChange={(e) => { setLevel(e.target.value); setPlanReady(false); }}><option>New to running</option><option>Some running</option><option>Regular running</option></select><label className="field-label" htmlFor="days">Days available for running each week</label><div className="choice-row">{[2,3,4].map((n) => <button key={n} className={`choice ${days === n ? "selected" : ""}`} onClick={() => { setDays(n); setPlanReady(false); }}>{n} days</button>)}</div><button className="primary-button full" onClick={() => setPlanReady(true)}>Build my starter week <span>→</span></button>{planReady && <div className="success-note"><span>✓</span> Your starter week is ready. It prioritizes comfortable effort and recovery.</div>}<p className="small-note">This is a conservative starter template, not a personalized medical or coaching assessment. Race-specific progression should be reviewed with a qualified running coach and a parent or guardian for younger runners.</p></section><section className="panel"><div className="panel-kicker">YOUR WEEK AT A GLANCE</div><h2>{goal} · Starter week</h2><p className="panel-intro">A sample structure based on your selected availability.</p><div className="plan-list">{week.map(([day,title,type,duration]) => <div className="plan-line" key={day}><span>{day}</span><div><b>{title}</b><small>{type}</small></div><strong>{duration}</strong></div>)}</div></section></div>}

        {active === "Workouts" && <section className="panel wide-panel"><div className="panel-kicker">WORKOUT LIBRARY</div><h2>Know the purpose of each session.</h2><p className="panel-intro">Keep most running comfortable. You don't need to race your training sessions.</p><div className="workout-library">{[{n:"Easy run",tag:"FOUNDATION",d:"A relaxed run where you can speak in full sentences. Build consistency without chasing pace."},{n:"Long easy run",tag:"ENDURANCE",d:"A slightly longer comfortable session. Keep the effort gentle and shorten it if you feel unusually tired."},{n:"Recovery day",tag:"RESET",d:"A rest day, easy walk, or gentle mobility session. Recovery is a real part of the plan."},{n:"Mobility & strength",tag:"SUPPORT",d:"Simple, controlled movement that supports coordination and general strength. Keep it comfortable."}].map((w) => <article className="library-card" key={w.n}><span className="library-icon">✳</span><div><small>{w.tag}</small><h3>{w.n}</h3><p>{w.d}</p></div></article>)}</div></section>}

        {active === "Recovery" && <section className="panel wide-panel"><div className="panel-kicker">RECOVERY CHECK-IN</div><h2>How are you feeling today?</h2><p className="panel-intro">A quick reflection can help you make a sensible choice about today's activity.</p><div className="recovery-options">{["Feeling good", "A little tired", "Need a rest day"].map((v) => <button className="recovery-option" key={v} onClick={() => setName(name || "Runner")}><span>{v === "Feeling good" ? "☀" : v === "A little tired" ? "☁" : "♡"}</span><b>{v}</b><small>{v === "Feeling good" ? "Keep to the planned comfortable effort." : v === "A little tired" ? "Consider an easier session." : "Rest is a productive choice."}</small></button>)}</div><div className="info-banner">If you feel pain, unwell, or unusually exhausted, pause training and talk with a trusted adult and an appropriate health professional.</div></section>}

        {active === "Analytics" && <section className="panel wide-panel"><div className="panel-kicker">TRAINING INSIGHTS</div><h2>Your progress, without the pressure.</h2><p className="panel-intro">Your charts will become meaningful once you add real activities. No demo numbers are presented as your personal results.</p><div className="empty-state"><span>↗</span><b>Your activity story starts here.</b><p>Log a run or connect an activity platform when integrations become available. PacePilot can then summarize consistency and trends.</p><button className="primary-button" onClick={() => setActive("Integrations")}>Explore integrations →</button></div></section>}

        {active === "Race center" && <section className="panel wide-panel"><div className="panel-kicker">RACE CENTER</div><h2>A goal to look forward to.</h2><p className="panel-intro">Choose a distance in Training plan to make it your current focus. Add an event date when you have one.</p><div className="race-goals">{(["General fitness", "5K", "10K", "Half-marathon", "Marathon"] as Goal[]).map((g) => <button key={g} className={`race-goal ${goal === g ? "selected" : ""}`} onClick={() => { setGoal(g); setActive("Training plan"); }}><span>{g === "General fitness" ? "✳" : "◎"}</span><b>{g}</b><small>{goal === g ? "Current focus" : "Choose this goal"}</small></button>)}</div></section>}

        {active === "Integrations" && <section className="panel wide-panel"><div className="panel-kicker">CONNECTED APPS</div><h2>Your activities, in one place.</h2><p className="panel-intro">These connections are planned. The buttons below are previews only; live authorization and syncing are not enabled yet.</p><div className="integration-list">{["Garmin", "Strava", "COROS"].map((provider) => <div className="integration-row" key={provider}><div className="provider-mark">{provider.slice(0,1)}</div><div><b>{provider}</b><small>{connected.includes(provider) ? "Preview selected · not connected" : "Integration planned"}</small></div><button className="outline-action" onClick={() => connect(provider)}>{connected.includes(provider) ? "Selected" : "Preview"}</button></div>)}</div><div className="info-banner">Never enter your provider password into PacePilot. Official secure authorization will be required before any real connection is enabled.</div></section>}

        {active === "Settings" && <section className="panel settings-panel"><div className="panel-kicker">YOUR PREFERENCES</div><h2>Make PacePilot yours.</h2><label className="field-label" htmlFor="runner-name">Display name</label><input id="runner-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Your name"/><label className="field-label" htmlFor="units">Distance units</label><select id="units" value={unit} onChange={(e) => setUnit(e.target.value)}><option value="km">Kilometers (km)</option><option value="mi">Miles (mi)</option></select><div className="info-banner">Your preferences are currently stored only in this browser session. Account sign-in and cloud saving will be added in a later version.</div></section>}

        <footer className="footer"><span>PACEPILOT <b>EARLY ACCESS FOUNDATION</b></span><span>Free-first · Your data, your pace</span></footer>
      </div>
    </section>
  </main>;
}
