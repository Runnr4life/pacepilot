export type Goal = "general_fitness" | "5k" | "10k" | "half_marathon" | "marathon";
export type WorkoutKind = "easy" | "long" | "tempo" | "intervals" | "recovery" | "rest" | "cross_training";
export type Provider = "garmin" | "strava" | "coros";

export interface AthleteProfile {
  id: string;
  displayName: string;
  goal: Goal;
  goalDate?: string;
  experience: "new" | "recreational" | "experienced";
  daysAvailable: number;
  recentWeeklyKm: number;
  longestRecentRunKm: number;
  comfortableEasyPaceSecPerKm?: number;
  preferredUnits: "km" | "mi";
  ageBand?: "under_18" | "18_plus";
}

export interface PlannedWorkout {
  id: string;
  day: string;
  kind: WorkoutKind;
  title: string;
  distanceKm?: number;
  durationMinutes?: number;
  effort: "very_easy" | "easy" | "steady" | "moderate" | "rest";
  notes: string;
}

export interface Activity {
  id: string;
  provider: Provider | "manual";
  startedAt: string;
  distanceKm: number;
  durationSeconds: number;
  averageHeartRate?: number;
  perceivedEffort?: number;
}

export interface TrainingSnapshot {
  weeklyDistanceKm: number;
  longestRunKm: number;
  activityCount: number;
  averagePaceSecPerKm?: number;
}

/** A descriptive snapshot only; not a validated readiness score. */
export function summarizeActivities(activities: Activity[]): TrainingSnapshot {
  const weeklyDistanceKm = activities.reduce((sum, a) => sum + Math.max(0, a.distanceKm), 0);
  const longestRunKm = activities.reduce((max, a) => Math.max(max, a.distanceKm), 0);
  const seconds = activities.reduce((sum, a) => sum + Math.max(0, a.durationSeconds), 0);
  return {
    weeklyDistanceKm: round1(weeklyDistanceKm),
    longestRunKm: round1(longestRunKm),
    activityCount: activities.length,
    averagePaceSecPerKm: weeklyDistanceKm > 0 ? Math.round(seconds / weeklyDistanceKm) : undefined,
  };
}

/**
 * Conservative demo adjustment: flags a review when recent weekly volume is
 * materially above the athlete's stated baseline. It does not auto-prescribe
 * extra mileage or make injury-risk predictions.
 */
export function reviewWeeklyLoad(profile: AthleteProfile, completedKm: number): {
  status: "within_baseline" | "review_with_coach";
  message: string;
} {
  const baseline = Math.max(profile.recentWeeklyKm, 0);
  if (baseline === 0) return { status: "review_with_coach", message: "Build a baseline from several weeks of consistent, comfortable activity before adjusting the plan." };
  if (completedKm > baseline * 1.1) {
    return { status: "review_with_coach", message: "This week is above the stated baseline. Keep the next week steady and review recovery before making changes." };
  }
  return { status: "within_baseline", message: "No automatic increase suggested. Keep the plan steady and review how the training feels." };
}

export function paceLabel(secondsPerKm?: number): string {
  if (!secondsPerKm || !Number.isFinite(secondsPerKm)) return "Not set";
  const min = Math.floor(secondsPerKm / 60);
  const sec = Math.round(secondsPerKm % 60).toString().padStart(2, "0");
  return `${min}:${sec} /km`;
}

function round1(n: number): number { return Math.round(n * 10) / 10; }
