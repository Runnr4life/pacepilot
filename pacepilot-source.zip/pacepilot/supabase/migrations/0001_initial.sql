-- PacePilot initial schema. Apply in a Supabase project after reviewing policies.
create extension if not exists pgcrypto;

create table if not exists public.athlete_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Runner',
  goal text not null default 'general_fitness' check (goal in ('general_fitness','5k','10k','half_marathon','marathon')),
  experience text not null default 'new' check (experience in ('new','recreational','experienced')),
  days_available int not null default 3 check (days_available between 1 and 7),
  recent_weekly_km numeric(6,2) not null default 0 check (recent_weekly_km >= 0),
  longest_recent_run_km numeric(6,2) not null default 0 check (longest_recent_run_km >= 0),
  preferred_units text not null default 'km' check (preferred_units in ('km','mi')),
  age_band text check (age_band in ('under_18','18_plus')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table if not exists public.training_plans (
  id uuid primary key default gen_random_uuid(),
  athlete_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  goal text not null,
  start_date date not null,
  end_date date,
  status text not null default 'draft' check (status in ('draft','active','paused','completed')),
  plan_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.activities (
  id uuid primary key default gen_random_uuid(),
  athlete_id uuid not null references auth.users(id) on delete cascade,
  provider text not null default 'manual' check (provider in ('manual','garmin','strava','coros')),
  provider_activity_id text,
  started_at timestamptz not null,
  distance_km numeric(8,3) not null check (distance_km >= 0),
  duration_seconds int not null check (duration_seconds >= 0),
  average_heart_rate int,
  perceived_effort int check (perceived_effort between 1 and 10),
  raw_summary jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(athlete_id, provider, provider_activity_id)
);

create table if not exists public.provider_connections (
  id uuid primary key default gen_random_uuid(),
  athlete_id uuid not null references auth.users(id) on delete cascade,
  provider text not null check (provider in ('garmin','strava','coros')),
  status text not null default 'disconnected' check (status in ('pending','connected','error','disconnected')),
  provider_user_id text,
  scopes text[] not null default '{}',
  last_synced_at timestamptz,
  created_at timestamptz not null default now(),
  unique(athlete_id, provider)
);

alter table public.athlete_profiles enable row level security;
alter table public.training_plans enable row level security;
alter table public.activities enable row level security;
alter table public.provider_connections enable row level security;

create policy "athletes manage own profile" on public.athlete_profiles for all using (auth.uid() = id) with check (auth.uid() = id);
create policy "athletes manage own plans" on public.training_plans for all using (auth.uid() = athlete_id) with check (auth.uid() = athlete_id);
create policy "athletes manage own activities" on public.activities for all using (auth.uid() = athlete_id) with check (auth.uid() = athlete_id);
create policy "athletes manage own connections" on public.provider_connections for all using (auth.uid() = athlete_id) with check (auth.uid() = athlete_id);
